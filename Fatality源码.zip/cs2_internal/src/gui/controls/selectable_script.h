#pragma once

#include <gui/controls/selectable.h>


namespace evo::gui
{
	class selectable_script : public selectable
	{
	public:

	};
}
