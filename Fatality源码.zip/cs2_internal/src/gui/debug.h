#pragma once

#include <atomic>

namespace evo::gui
{
	inline std::atomic_uint64_t dbg_total_controls;
}
